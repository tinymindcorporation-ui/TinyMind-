Put llama.cpp here (optional, for faster GGUF models):
1. Download llama-...-bin-win-cpu-x64.zip from github.com/ggml-org/llama.cpp/releases
2. Unzip ALL its files into this llama folder (llama-server.exe must be here).
TinyMind finds it automatically on the next start and uses it (Settings > GGUF engine = Auto).
Without it, TinyMind uses its own built-in engine.
