Built-in AI models (offline). TinyMind uses the first .xfx or .gguf in this folder as its big brain automatically.
Put Qwen2-0.5B-Instruct-FinGreyLit-Q4_K_M.xfx (or any .gguf/.xfx) here.
