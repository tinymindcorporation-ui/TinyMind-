# TinyMind

**Your own AI, built from scratch.** TinyMind is a small Windows app (under 10 MB) with its own neural-network brain. It
learns from you, from your files and videos, and (if you allow it) from the internet and from big teacher models. It keeps
learning in the background while your PC is on, like a person who sleeps on what they learned.

> Honest note: TinyMind is a *small* AI. It knows what you teach it and the subjects it studies, but it is nowhere near
> the general knowledge of ChatGPT, Claude or Grok. It shows a confidence score with every answer, says
> "I'm not sure" instead of making things up, and learns when you correct it.

## Quick start

1. Copy `TinyMind.exe` anywhere, for example to your Desktop, and double-click it. It runs on Windows 10 and 11, which already include
   .NET Framework 4.8. Nothing else needs installing.
   If Windows SmartScreen warns about an unknown app, click **More info → Run anyway**. The app is unsigned because you
   built it yourself.
2. The welcome wizard asks your name and whether the brain should start **pre-trained** (recommended) or as a
   **true newborn**.
3. Chat. Teach it. Drag files onto the window.

## What it can do

| Feature | How |
|---|---|
| Chat | Type and press Enter. Every answer shows **% sure** and its **source**, plus buttons: Good · Correct me · Read aloud · Copy. |
| Teach | Turn on **Teach mode**, or start a message with `teach:`. Other forms: `question? = answer`, `my name is …`, `I like …`, and `when I say X reply Y` (which creates a new skill). |
| Learn from files | Drag and drop, use **+**, or use the **Learning Inbox** folder. It reads books and PDFs, Word, Excel, PowerPoint, OpenDocument, EPUB, RTF, HTML, subtitles, code, zip files and any other file. Videos and audio need ffmpeg (+ Whisper for good quality). Images need Tesseract. It then shows the **patterns** it found. |
| Learn from the internet | `learn about <topic>`, `learn <url>`, YouTube links, **DeepSearch** (`deep search <topic>`), `news about <topic>`. While you're away it explores the questions it couldn't answer. |
| Learn from big AI models | **Updates & teachers → Learn from a big model**: distillation from models on Hugging Face, including ~1-trillion-parameter models, using your free HF token. |
| Hugging Face datasets | **Updates & teachers → Hugging Face datasets**: type a dataset name and choose a size limit. |
| Update packages | `.tmpack` files with SHA-256 checksums install new lessons, skills, memories or brains. You can also export your own (see `docs/UPDATE_PROTOCOL.md`). |
| Languages | English, Hindi, Japanese, Chinese, Sanskrit, Bengali and German: a phrasebook plus basic conversation. It detects which language you write in. |
| Bhagavad Gita | The 18 chapters, key ideas and famous verses in Sanskrit. Feed it a full Gita text to learn every verse. |
| Python | `write python code to …`, then **Run code**. It always asks first, and errors become lessons. |
| Agent actions | `open notepad`, `open youtube`, `find file report`, `run: dir` (asks first), `calculate 15% of 2400`, the time and date. |
| Think mode | Shows its reasoning: the memories it recalled, the drafts it considered, and why it picked an answer. |
| Personality | Regular, Fun, Teacher or Concise. |
| Voice | The microphone button to talk and the speaker button to hear replies, using Windows' built-in speech. |
| Skills | **Settings & skills → Skills**: turn skills on or off, create, edit, duplicate or delete them, and test which skill answers a message. |
| 100 tool skills | Built in and offline. Maths (equations, matrices, calculus, big numbers, logic), science and quantum (molar mass, photon energy, de Broglie, Bohr levels, particle in a box, pH, gas law), money (EMI, SIP, GST, compound interest), text tools, dates and reminders, a to-do list, habits and expenses, PC tools (duplicates, largest files, grep, diff, checksum, zip, organize), and brain tools (quiz, spaced review, knowledge graph, two-brain consensus, study planner, Anki export, storage report against the 500 MB limit). Three use the internet: swarm study, RSS and define. Full list in Help. |
| Two characters | **Arjun 👦** and **Meera 👧** (rename them in Settings). Each has their own neural brain, voice and avatar, and they share memory and training. Switch between them in the header, or use **Ask both**. |
| 15 agents | **Learning Center → Agents**: 15 workers that study topics, read files, ask teacher models and run DeepSearch in parallel, with live status cards. |
| Software update from GGUF | **Big models · datasets → Update packages → Install update from GGUF**. TinyMind runs the model with llama.cpp, asks it a whole curriculum, and learns every answer. It can keep the model as a **helper brain** to ask when unsure. |
| File Reader | Outline and summary for `.py .ts .js .sh .md .json` (sidebar, or `read file <path>` in chat). |
| Two windows | **Chat** for conversation, and the **Learning Center** (Brain · Teach · Files · Inbox · Big models · datasets · GGUF · Autonomy) for everything about learning. |
| Autonomy | Idle only, **While I work** (gentle background learning) or **Full autonomy** (it picks its own topics within daily limits; learning only, never commands). |
| GGUF models | **GGUF Reader** window: open any `.gguf` to see parameters, layers, quantization, metadata, tensors and a layer chart. Run one with llama.cpp as a local, offline teacher, or download one from Hugging Face. |
| Brain & learning | Live neuron view, inner voice, stage (Newborn → Baby → Toddler → Child → Student → Scholar), journal, and a **Performance** panel: brain size (Small, Standard, Large ≈150 MB, **Grand ≈300 MB**), RAM up to 6 GB, CPU cores, speed test, "start as newborn". |

## How it learns (like a brain)

- **Hippocampus (fast memory).** What you teach it is remembered instantly.
- **Cortex (neural network).** After every chat its neurons adjust a little (awake learning).
- **Sleep learning.** When you're idle (and on a laptop, plugged in), it rehearses everything it has seen, studies the
  Learning Inbox, explores curiosities online, tidies its memory, and tunes its own learning speed by trial and error.
  Closing the window keeps it learning from the system tray.

## Your data

Everything stays in your TinyMind folder, by default `%LOCALAPPDATA%\TinyMind`. It holds a `System` folder (brain,
knowledge, training data), plus `Skills`, `Chats`, `Journal` and `Learning Inbox`. See `docs/FOLDERS.md`. Back up that folder to
keep your AI. **Storage budget:** the brains of both characters are kept under 300 MB together (weights + learning state), and everything else (memory, training texts, backups, app) uses the other 200 MB. Downloaded GGUF models in `Models\` are separate.

## For builders

- `docs/DESIGN.md`: brain architecture, design-contest results, and every file schema
- `docs/UPDATE_PROTOCOL.md`: the `.tmpack` format and update channels
- `docs/simulation.html`: an interactive simulation of the brain
- `source/`: all source code. `build.sh` (Linux/WSL with Mono) or `build.bat` (Windows with the built-in C# compiler) rebuilds the app.
  `pretrain/` holds the Python scripts that made the starter brain.

TinyMind's training code follows the structure of Andrej Karpathy's llm.c (MIT license).
