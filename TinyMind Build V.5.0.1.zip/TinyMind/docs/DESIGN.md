# TinyMind — brain design and schema

TinyMind is a small AI built from scratch. Its design copies how a brain splits up work: fast memory, slow
learning, sleep, attention, and self-checking. It uses no outside AI model or library. Every part is in
`source/src/`.

```
            ┌──────────────────────────── SENSES ────────────────────────────┐
            │ keyboard · microphone (Windows speech) · files · Learning Inbox │
            │ internet (Wikipedia, web pages, YouTube subtitles) — optional   │
            └───────────────────────────────┬────────────────────────────────┘
                                            ▼
                         ┌──────── 1. TRIAGE (intent routing) ────────┐
                         │ teaching? → TEACH        skill trigger? →    │
                         │ SKILLS / ACTIONS (open, find, run, search,   │
                         │ calc, python, journal, self...)  else ↓      │
                         └──────────────────────────────────────────────┘
                                            ▼
     ┌──── 2. HIPPOCAMPUS (Memory.cs) ────┐     ┌──── 3. CORTEX (Brain.cs) ─────────────────┐
     │ fast memory: facts, preferences,    │     │ neural network that reads raw bytes        │
     │ taught answers, lessons, knowledge  │────▶│ (ASCII / UTF-8). Gets the best memories    │
     │ "attention": word + letter-pattern  │notes│ as notes + working memory (last exchange). │
     │ vectors + keyword scoring           │     │ Writes several drafts (self-check).        │
     └─────────────────────────────────────┘     └────────────────────┬───────────────────────┘
                                                                      ▼
                         ┌──────── 4. JUDGE (confidence) ──────────────┐
                         │ score drafts: byte confidence, repetition,  │
                         │ agreement with memory → best draft + % sure │
                         │ low confidence → answer from memory, or say │
                         │ "I'm not sure" + add to curiosity list       │
                         └──────────────────────┬──────────────────────┘
                                                ▼
                         REPLY (text / voice) + source + confidence %
                                                │
                    ┌───────────────────────────┴──────────────────────────┐
                    ▼                                                       ▼
        AWAKE LEARNING (instant)                             SLEEP LEARNING (idle + plugged in)
        every exchange → a few backprop steps                rehearse a mix of chats, teachings, files,
        mixed with a little rehearsal                        lessons · study Learning Inbox · explore
                                                             curiosities online · dedupe memory ·
                                                             trial-and-error learning speed · daily reflection
```

## 1. The cortex: a neural network

| Part | What it is |
|---|---|
| Input | Raw bytes, so 256 possible symbols. English is plain ASCII; Hindi, Sanskrit and every other language arrive as UTF-8 bytes. No tokenizer is needed. |
| Turn markers | Byte 1 = user, 2 = AI, 3 = end of turn, 4 = note (recalled memories). |
| Architecture | A GPT-style decoder-only transformer. Each layer has token and position embeddings, LayerNorm, causal multi-head self-attention, and a GELU MLP (4× width), with residual connections and tied input/output embeddings. |
| Learning | Cross-entropy on the next byte, backpropagation written by hand, AdamW (β = 0.9 / 0.95) and gradient clipping at 1.0. A tuner adjusts the learning rate by trial and error. |
| Thinking | A key/value cache, so each new byte costs about 2 × parameters operations. Sampling is top-k with a temperature. |
| Correctness | The gradient check shows 0 of 40 mismatches. Outputs match a PyTorch reference to 4 decimal places. |

### Brain sizes (context = 256 bytes)

| Size | Width × layers × heads | Connections | Weights on disk |
|---|---|---|---|
| Small | 128 × 4 × 4 | ~0.9 M | ~3.5 MB |
| **Standard (built-in, pre-trained)** | 256 × 4 × 8 (contest winner) | ~3.3 M | ~13 MB (fp32) / ~6.6 MB in the .exe (fp16) |
| Large | 384 × 7 × 6 | ~12.6 M | ~50 MB weights, **~150 MB brain file** with learning state |
| **Grand** (the finest the budget allows) | 512 × 8 × 8 | ~25.4 M | ~100 MB weights, **~300 MB brain file** |

**Storage budget: 500 MB.** The brain files of both characters (weights + AdamW learning state) may use **300 MB** together,
so they can both be Large, or one can be Grand. The other **200 MB** holds the app, memory, training texts and
half-precision backups (Large/Grand keep fewer backups).

### Two characters, one mind

Arjun 👦 and Meera 👧 each have their own cortex (`System/Brain/boy`, `System/Brain/girl`), tuner and voice. They
share the hippocampus (memory), skills and training library. Whatever you teach is practised by both brains, but they
grow differently because each chats and sleep-learns on its own. Their brains train one step at a time (a shared lock),
and the RAM budget is split between them.

### 15 parallel agents

`AgentPool` runs 15 worker threads over one job queue: study a topic (Wikipedia), read a file, ask a teacher model,
or DeepSearch. Downloading, parsing and memory-writing run truly in parallel. Neuron updates are serialized
per brain. In full autonomy, sleep chores hand several topics to the agents at once, and each agent claims its own topic.

### Software update from GGUF (distillation) and the helper brain

`Install update from GGUF` checks the file, starts it with llama.cpp (`127.0.0.1:8089`), and builds a curriculum:
- your focus subject
- open curiosities
- 25 general subjects (science, history, Gita, Python, Hindi phrases…)

It asks about `questions / topics` questions per topic and stores each answer as a memory and a lesson for both
brains. If "ask helper when unsure" is on, any chat answer under 45% confidence is escalated to the GGUF model, and
its answer is shown and learned. This is the small-model "escalation" pattern: TinyMind stays fast and honest, and
grows from every question it couldn't answer.

### Trial-and-error design contest

Seven designs were each trained from random neurons for the same 2.5 minutes on the same lessons. They were
then scored on held-out text (every 30th 4 KB block, never trained on). Lower test error is better.

| Design (width × layers × heads) | Learning rate | Connections | Steps in 2 min | Test error (nats/byte) |
|---|---|---|---|---|
| **256 × 4 × 8 (winner)** | **0.003** | **3.29 M** | 219 | **2.316** |
| 320 × 3 × 8 | 0.002 | 3.86 M | 206 | 2.348 |
| 256 × 4 × 8 | 0.002 | 3.29 M | 223 | 2.375 |
| 192 × 6 × 6 (first design) | 0.002 | 2.77 M | 239 | 2.436 |
| 160 × 8 × 5 | 0.002 | 2.56 M | 229 | 2.502 |

**What trial and error showed:** with a short training budget, *wider and shallower* brains learn faster than *deep and
narrow* ones, and a slightly higher learning rate helps. The winner then trained for 30 minutes and became the built-in
**Standard** brain. Inside the app, the trial-and-error tuner keeps adjusting the learning speed the same way.

## 2. The hippocampus: memory schema

`System/Knowledge/memory.json`:

```json
{ "version": 2,
  "items": [
    { "id": "9f1c…",                 // unique id
      "text": "The user's name is Ravi.",
      "kind": "fact",                // fact | preference | answer | lesson | knowledge | summary | curiosity | note
      "source": "taught by you",     // taught by you | corrected by you | book:file.pdf | web:… | built-in lessons
      "q": "who is my best friend?", // only for kind=answer: the question it answers
      "created": "2026-11-07T20:45:00.0000000+05:30",
      "uses": 3,                     // how often it was recalled
      "done": true }                 // curiosities: already explored
  ] }
```

Recall works like attention:
**score = 0.55 × cosine(meaning vectors) + 0.45 × keyword match (IDF-weighted)**, with small boosts for personal
and recent memories. Meaning vectors are 1,024-slot hashed vectors of words plus 3-letter patterns, so
spelling variants still match.

## 3. Skill schema (`Skills/<name>/SKILL.md`)

```markdown
---
name: morning-greeting
description: Greets me in the morning.
action: reply            # reply | open | command | search | learnweb | python | memory | calc | time | findfile | journal | self | teach
triggers: good morning tinymind, gm tinymind     # comma separated; ending with ':' = must be at the start
enabled: true
---
Good morning {name}! Ready for a great day?      # body: reply text / app or site to open / command ({input} = your message)
```

Skills are matched by their longest trigger. You can edit them in **Settings → Skills**: turn them on or off,
edit them, duplicate them, delete them, or test which skill would answer a message. TinyMind also creates skills itself
(for example from "when I say X, reply Y").

## 4. Brain file schema (`System/Brain/brain.bin`, little-endian)

| Field | Type |
|---|---|
| magic `TMB1` (0x31424D54) | int32 |
| T, C, L, NH | 4 × int32 |
| steps, bytes seen | 2 × int64 |
| last loss, test loss | 2 × float32 |
| born (.NET DateTime binary) | int64 |
| half-precision flag | int32 |
| weights, in order: wte, wpe, ln1 w/b, qkv w/b, proj w/b, ln2 w/b, fc w/b, fcproj w/b, lnf w/b | fp32 or fp16 |
| optimizer flag + AdamW m, v | int32 + 2 × fp32 arrays (optional) |

Every save is journaled (written to a temp file, then swapped in atomically). A SHA-256 checksum is stored in
`brain.bin.sha256`. If the brain file is damaged, the newest good backup is loaded automatically.

## 5. Training data schema (`System/Training/*.txt`)

Plain UTF-8 text, one file per source. Conversations use the turn markers:

```
\x04<note: recalled facts>\n\x01<user message>\x02<AI reply>\x03\n
```

Sleep learning samples random 257-byte windows (starting at a line or turn boundary). Each source is
weighted by √size, with extra weight for:
- teachings (×4)
- chats (×3)
- your focus subject (×3)
- recently added files (up to ×3, fading over a few days)

The starter lessons get a lower weight (×0.8). Mixing old material with new is what keeps the brain from
forgetting: sleep replay.

## 6. Autonomy

| Level | Behaviour |
|---|---|
| Idle only | Sleep learning starts after N idle minutes and uses all cores but one. |
| While I work | Also learns in the background while you work: 1 core, about ⅓ duty cycle, small batches. It pauses while you chat and when the laptop is on battery. |
| Full autonomy | Also runs a self-directed curriculum about every 10 minutes: pick a topic (curiosities → focus subject → topics found while reading), study it on Wikipedia, the web, or a teacher model (cloud or local GGUF), make memories and lessons, then add 3 newly discovered topics. |

Guardrails for autonomous learning:
- It only reads and learns. It never runs commands or opens apps.
- It writes only inside its own folder.
- Daily limits apply to downloads and teacher questions (`System/Brain/autonomy.json`).
- Every step is logged in the Journal.

## 7. GGUF models

TinyMind reads GGUF v2/v3 files (header, metadata and tensor list, without loading weights). The **GGUF Reader** window
shows overview cards, every metadata key, a sortable tensor table and a size-per-layer chart. A GGUF model can't be
merged into TinyMind's differently shaped brain. Instead, TinyMind starts it with llama.cpp's `llama-server` on
`127.0.0.1:8089` and learns from its answers, offline. That is local distillation.

## 8. Honest limits

- It is a small brain. It is good at what you teach it and at its focus subject, and weak on general knowledge.
  It is nowhere near Claude or ChatGPT, and it shows a confidence score so you can tell when it's guessing.
- Learning runs on the CPU, at roughly a few thousand bytes per second on a laptop, depending on brain size.
  The NVIDIA MX330 is not used.
- Learning from video audio needs ffmpeg (plus Whisper for good quality). Reading images needs Tesseract.
  Scanned PDFs need OCR.
