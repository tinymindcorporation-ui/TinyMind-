# TinyMind folder structure

## 1. What you download

```
TinyMind/
├── TinyMind.exe              ← the app (under 10 MB, includes the starter brain + lessons)
├── README.md                 ← quick start and user guide
├── docs/
│   ├── DESIGN.md             ← how the brain works + every data schema
│   ├── FOLDERS.md            ← this file
│   └── simulation.html       ← interactive brain simulation (open in a browser)
└── source/                   ← full source code, so you can change and rebuild everything
    ├── build.sh              ← rebuilds TinyMind.exe (Linux/WSL: mono; or use build.bat with .NET on Windows)
    ├── build.bat
    ├── src/                  ← the app (C#, .NET Framework 4.8, built into Windows 10/11)
    │   ├── Brain.cs          ← the neural network (cortex): transformer, backprop, AdamW, generation
    │   ├── Cortex.cs         ← how the brain learns: instant + sleep learning, RAM/batch, sizes, tuner, speed test, journal
    │   ├── Memory.cs         ← hippocampus: fast long-term memory with attention-style search
    │   ├── Mind.cs           ← thinking: triage, teaching, recall, self-check, confidence, self-model, sleep chores
    │   ├── Agent.cs          ← skills (SKILL.md), PC actions, web search / Wikipedia / pages
    │   ├── FileLearner.cs    ← reads any file type + Pattern Finder
    │   ├── Voice.cs          ← speaking and listening (Windows speech)
    │   ├── Settings.cs       ← settings + the System folder layout
    │   ├── Json.cs           ← small JSON helpers
    │   ├── Program.cs        ← start-up, tray, start-with-Windows, Material theme
    │   ├── MainForm.cs       ← main chat window
    │   ├── ChatView.cs       ← chat bubbles, welcome cards, answer buttons
    │   ├── Forms.cs          ← Brain panel, Settings (+ Skills editor), Memory window
    │   ├── LearningForm.cs   ← Learning Center window (Brain · Teach · Files · Big models · GGUF · Autonomy)
    │   ├── UpdatesForm.cs    ← teacher models, Hugging Face datasets, update packages
    │   ├── Updates.cs        ← distillation, datasets API, .tmpack install/export, encrypted token
    │   ├── Gguf.cs           ← GGUF reader + local llama.cpp teacher + GGUF download
    │   ├── AgentPool.cs      ← 15 parallel worker agents
    │   ├── FileReader.cs     ← File Reader for .py .ts .js .sh .md .json (outline + summary)
    │   ├── GgufForm.cs       ← GGUF Reader window
    │   └── UiExtras.cs       ← rounded panels, pill buttons, snackbars, help, welcome wizard
    ├── pretrain/             ← how the starter brain was made (Python + PyTorch, optional)
    │   ├── make_corpus.py    ← writes the "childhood lessons" (starter.txt)
    │   ├── gita.py           ← Bhagavad Gita lessons
    │   ├── train_seed.py     ← trains a brain from random neurons and exports it
    │   ├── languages.py      ← phrases in English, Hindi, Japanese, Chinese, Sanskrit, Bengali, German
    │   ├── trials.sh         ← trial-and-error brain design contest
    │   └── trials.log        ← the contest results
    └── tests/                ← correctness tests (gradient check, PyTorch parity, full mind test)
```

## 2. TinyMind's own "System32" (created on first run)

Default location: `C:\Users\<you>\AppData\Local\TinyMind` (change it in Settings → Data folder, e.g. `D:\TinyMind`).
Settings live separately in `%APPDATA%\TinyMind\settings.json`, so the data folder can move.

```
TinyMind/
├── System/                       ← core folder, marked as a Windows "system" folder. Don't edit by hand.
│   ├── README.txt
│   ├── Brain/                    ← CORTEX: the neurons (own brains together ≤ 1 GB)
│   │   ├── boy/                  ← Arjun's brain
│   │   │   ├── brain.bin         ← weights + learning state (journaled save)
│   │   │   ├── brain.bin.sha256  ← checksum; a damaged brain is restored from backup
│   │   │   ├── tuner.json        ← his trial-and-error learning speed
│   │   │   └── Backups/          ← half-precision daily backups
│   │   ├── girl/                 ← Meera's brain (same layout)
│   │   ├── gguf/                 ← the GGUF big brain (≤ 4 GB), installed from Update packages
│   │   └── autonomy.json         ← today's autonomous-learning budget (downloads, teacher questions)
│   ├── Knowledge/                ← HIPPOCAMPUS: long-term memory
│   │   ├── memory.json           ← facts, preferences, taught answers, lessons, knowledge, curiosities
│   │   └── seeded.flag
│   └── Training/                 ← everything it learns from, one plain-text file per source
│       ├── starter.txt           ← childhood lessons (from the .exe)
│       ├── chats.txt             ← your conversations (turn markers: bytes 1/2/3/4)
│       ├── teachings.txt         ← what you taught + corrections (studied 4× more)
│       ├── teacher-lessons.txt   ← answers learned from teacher models (cloud or local GGUF)
│       ├── dataset-<name>.txt    ← Hugging Face datasets
│       ├── book-<name>.txt       ← PDFs / e-books
│       ├── document-<name>.txt   ← Word, RTF, OpenDocument
│       ├── video-<name>.txt      ← video transcripts / subtitles
│       ├── web-<name>.txt        ← Wikipedia and web pages
│       └── code-<name>.txt       ← source code
├── Skills/                       ← one folder per skill, each with a SKILL.md (edit in Settings → Skills)
│   ├── teacher/SKILL.md
│   ├── python-coder/SKILL.md
│   ├── gita-teacher/SKILL.md
│   └── ...
├── Chats/                        ← chat history shown in the sidebar (one .json per chat)
├── Models/                       ← downloaded .gguf teacher models (downloads; install one as the big brain to use it)
├── Journal/                      ← "What I learned" diary, one file per day
│   └── YYYY-MM-DD.txt
├── Logs/
│   └── log.txt                   ← technical log (errors, restores)
└── Learning Inbox/               ← DROP FILES HERE: studied automatically while you're away
    └── _Learned/                 ← files move here after studying
```

**Backup tip:** copy the whole `TinyMind` folder to keep your AI safe, or to move it to another PC.
