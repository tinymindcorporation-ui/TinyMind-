# TinyMind update protocol (`tinymind-pack/1`)

TinyMind can grow from three outside sources. All three appear in the app under **Updates & teachers**.

| Road | What comes down | How it learns |
|---|---|---|
| **Teacher model (distillation)** | Answers from a large model running on a server, such as Hugging Face Inference Providers. Models of about 1 trillion parameters, like Kimi K2, are available there. | Each question and answer becomes a memory and a lesson in `System/Training/teacher-lessons.txt`, so the brain practises it. |
| **Hugging Face dataset** | Rows of text fetched from `datasets-server.huggingface.co/rows` in pages of 100, up to the size you set. | The text is saved to `System/Training/dataset-*.txt`, chunked into memory, and studied during sleep learning. |
| **Update package (`.tmpack`)** | A zip containing lessons, skills, memories and/or a brain. | Every file is checked, then installed. A new brain replaces the current one, which is backed up first. |

A 1-trillion-parameter model itself is never downloaded. Its weights take up about 2 TB and need a server
with many GPUs. Distillation, where a small student learns from a big teacher's answers, is the practical way
to bring that knowledge down to a laptop.

## Package format

A `.tmpack` file is a zip:

```
my-update.tmpack
├── manifest.json
├── brain/brain.bin          (optional) role "brain"     – TinyMind brain file (see DESIGN.md §4)
├── training/lessons.txt     (optional) role "training"  – UTF-8 text / dialogues with turn bytes 1-4
├── skills/greeter.md        (optional) role "skill"     – a SKILL.md
└── memory/memory.json       (optional) role "memory"    – [ { "text": "...", "kind": "fact", "q": null }, ... ]
```

`manifest.json`:

```json
{
  "format": "tinymind-pack/1",
  "name": "gita-complete",
  "version": "1.0.0",
  "created": "2026-11-07T21:00:00+05:30",
  "description": "All 700 verses of the Bhagavad Gita with meanings",
  "files": [
    { "path": "training/gita.txt", "role": "training", "sha256": "9F86D081884C7D65..." },
    { "path": "skills/gita-teacher.md", "role": "skill", "sha256": "..." }
  ]
}
```

### Install rules

1. `format` must be `tinymind-pack/1`.
2. **All SHA-256 checksums are verified before anything is changed.** If one fails, nothing is installed.
3. Before a `brain` is installed, the current brain is saved to `System/Brain/Backups/before-update-<time>.bin`.
4. Memories are deduplicated. Skills with the same name are replaced.
5. Each install is written to the Journal.

## Update channel (Hugging Face repo)

Publish updates in any Hugging Face model or dataset repo, for example `yourname/tinymind-updates`:

```
latest.json      { "version": "1.1.0", "url": "https://huggingface.co/yourname/tinymind-updates/resolve/main/tinymind-1.1.0.tmpack", "notes": "Learned 5 books" }
tinymind-1.1.0.tmpack
```

In TinyMind, enter `yourname/tinymind-updates` as the **Update channel**, then click **Check for updates** and
**Install update**. **Export my TinyMind as a package** builds a `.tmpack` from your current brain, taught
knowledge and skills. Upload it to share your trained AI with another PC.

## Security notes

- Install packages only from people you trust. A brain or lesson can teach the AI anything.
- Your Hugging Face token is stored encrypted for your Windows account (DPAPI). It is sent only to the teacher
  server and the Hugging Face APIs you configure.
- Teacher models on Inference Providers use your Hugging Face credits. Watch your usage on huggingface.co.
